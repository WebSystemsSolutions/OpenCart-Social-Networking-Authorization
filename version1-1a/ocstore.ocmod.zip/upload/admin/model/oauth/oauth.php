<?php
class ModelOauthOauth extends Model {

}