INSERT INTO `oc_url_alias` (`query`, `keyword`) VALUES ('auth/oauth/glogin','glogin');

