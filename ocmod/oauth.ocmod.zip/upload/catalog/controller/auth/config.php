<?php

//Google Конфіг

$google = ['client_secret' => '','client_id' => '' , 'redirect_url' => 'http://reg.dix.ua/glogin'];


?>
